#ifndef _GLOBALS_HPP_
#define _GLOBALS_HPP_



#define NOTDEFINED 0
#define HORIZONTAL 1
#define VERTICAL 2



#endif