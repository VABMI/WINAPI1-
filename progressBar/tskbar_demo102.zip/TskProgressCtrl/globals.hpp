#ifndef _GLOBALS_HPP_
#define _GLOBALS_HPP_


#define NOTDEFINED 0
#define HORIZONTAL 1
#define VERTICAL 2


#define BATTERYX // If defined, Progressbar is in use for Project BatteryX


#endif