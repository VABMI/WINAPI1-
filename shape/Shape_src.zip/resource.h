//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Shape.rc
//
#define IDR_CNTR_INPLACE                6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_FAILED_TO_CREATE            102
#define IDR_MAINFRAME                   128
#define IDR_SHAPETYPE                   129
#define ID_CANCEL_EDIT_CNTR             32768
#define ID_TEST_SHAPE                   32771
#define ID_TEST_MAKEELLPTICAL           32772
#define ID_TEST_MAKEPOLYGAN             32773
#define ID_TEST_MAKEROUNDEDCORNER       32774
#define ID_CHANGEWINDOWSHAPES_MAKETRIANGLE 32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
