//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by listview.rsrc.rc
//
#define IDC_DIALOG                      101
#define IDI_ICON1                       102
#define IDR_MENU1                       106
#define IDC_LIST                        1000
#define IDC_DELSELITEM                  1001
#define IDC_DELALL                      1002
#define IDC_ADD                         1004
#define IDC_ADDSUB                      1005
#define IDC_ADDITEM                     1006
#define IDC_ADDSUBITEM                  1007
#define IDC_BOTH                        1008
#define IDC_RENAME                      40002
#define IDC_SELECT_ALL                  40004
#define IDC_LAST_ITEM                   40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
