// SendToShlExt.cpp : Implementation of CSendToShlExt

#include "stdafx.h"
#include "resource.h"
#include "SendToClone.h"
#include "SendToShlExt.h"
#include "SendToCloneDlg.h"

/////////////////////////////////////////////////////////////////////////////

class CActCtx
{
public:
    CActCtx() : m_ulActivationCookie(0), m_hActCtx(INVALID_HANDLE_VALUE)
    {
        if ( Init() )
            ActivateActCtx ( m_hActCtx, &m_ulActivationCookie );
    }

    ~CActCtx()
    {
        if ( INVALID_HANDLE_VALUE != m_hActCtx )
            {
            DeactivateActCtx ( 0, m_ulActivationCookie );
            ReleaseActCtx ( m_hActCtx );
            }
    }

    bool Init()
    {
    bool bRet = false;

        // Do special theme activation code only on XP+
        if ( _winmajor > 5 || (_winmajor == 5 && _winminor >= 1) )
            {
            // NOTE: This code explicitly uses the Unicode versions of ACTCTX
            // and CreateActCtx() because there is no IsolationAwareXxx
            // wrapper for CreateActCtxA().
            USES_CONVERSION;
            ACTCTXW actctx = { sizeof(ACTCTXW) };
            TCHAR szModule[MAX_PATH];

            GetModuleFileName ( AfxGetInstanceHandle(), szModule, countof(szModule) );

            actctx.dwFlags = ACTCTX_FLAG_RESOURCE_NAME_VALID;
            actctx.lpSource = T2CW(szModule);
            actctx.lpResourceName = MAKEINTRESOURCEW(ISOLATIONAWARE_MANIFEST_RESOURCE_ID);

            m_hActCtx = CreateActCtxW ( &actctx );

            if ( INVALID_HANDLE_VALUE != m_hActCtx )
                bRet = true;
            }

        return bRet;
    }

protected:
    ULONG_PTR m_ulActivationCookie;
    HANDLE m_hActCtx;
}; 


/////////////////////////////////////////////////////////////////////////////
// CSendToShlExt

STDMETHODIMP CSendToShlExt::DragEnter (
    IDataObject* pDataObj, DWORD grfKeyState,
    POINTL pt, DWORD* pdwEffect )
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());    // init MFC

COleDataObject dataobj;
TCHAR          szItem[MAX_PATH];
UINT           uNumFiles;
HGLOBAL        hglobal;
HDROP          hdrop;

    dataobj.Attach ( pDataObj, FALSE ); // attach to the IDataObject, don't auto-release it

    // Read the list of items from the data object.  They're stored in HDROP
    // form, so just get the HDROP handle and then use the drag 'n' drop APIs
    // on it.
    hglobal = dataobj.GetGlobalData ( CF_HDROP );

    if ( NULL != hglobal )
        {
        hdrop = (HDROP) GlobalLock ( hglobal );

        uNumFiles = DragQueryFile ( hdrop, 0xFFFFFFFF, NULL, 0 );

        for ( UINT uFile = 0; uFile < uNumFiles; uFile++ )
            {
            if ( 0 != DragQueryFile ( hdrop, uFile, szItem, MAX_PATH ) )
                m_lsDroppedFiles.AddTail ( szItem );
            }

        GlobalUnlock ( hglobal );
        }

    if ( m_lsDroppedFiles.GetCount() > 0 ) 
        {
        *pdwEffect = DROPEFFECT_COPY;
        return S_OK;
        }
    else
        {
        *pdwEffect = DROPEFFECT_NONE;
        return E_INVALIDARG;
        }
}

STDMETHODIMP CSendToShlExt::Drop (
    IDataObject* pDataObj, DWORD grfKeyState,
    POINTL pt, DWORD* pdwEffect )
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());    // init MFC

CSendToCloneDlg dlg ( &m_lsDroppedFiles );
CActCtx ctx;

    dlg.DoModal();

    *pdwEffect = DROPEFFECT_COPY;
    return S_OK;
}
