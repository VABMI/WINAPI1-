// SendToShlExt.h : Declaration of the CSendToShlExt

#ifndef __SENDTOSHLEXT_H_
#define __SENDTOSHLEXT_H_

/////////////////////////////////////////////////////////////////////////////
// CSendToShlExt

class ATL_NO_VTABLE CSendToShlExt : 
    public CComObjectRootEx<CComSingleThreadModel>,
    public CComCoClass<CSendToShlExt, &CLSID_SendToShlExt>,
    public IPersistFile,
    public IDropTarget
{
public:
    CSendToShlExt() { }

    BEGIN_COM_MAP(CSendToShlExt)
        COM_INTERFACE_ENTRY(IPersistFile)
        COM_INTERFACE_ENTRY(IDropTarget)
    END_COM_MAP()

    DECLARE_REGISTRY_RESOURCEID(IDR_SENDTOSHLEXT)

public:
    // IPersistFile
    STDMETHODIMP GetClassID(LPCLSID)      { return E_NOTIMPL; }
    STDMETHODIMP IsDirty()                { return E_NOTIMPL; }
    STDMETHODIMP Load(LPCOLESTR, DWORD)   { return S_OK;      }
    STDMETHODIMP Save(LPCOLESTR, BOOL)    { return E_NOTIMPL; }
    STDMETHODIMP SaveCompleted(LPCOLESTR) { return E_NOTIMPL; }
    STDMETHODIMP GetCurFile(LPOLESTR*)    { return E_NOTIMPL; }

    // IDropTarget
    STDMETHODIMP DragEnter(IDataObject* pDataObj, DWORD grfKeyState,
                           POINTL pt, DWORD* pdwEffect);

    STDMETHODIMP DragOver(DWORD grfKeyState, POINTL pt, DWORD* pdwEffect)
        { return E_NOTIMPL; }

    STDMETHODIMP DragLeave()
        { return S_OK; }

    STDMETHODIMP Drop(IDataObject* pDataObj, DWORD grfKeyState,
                      POINTL pt, DWORD* pdwEffect);

protected:
    CStringList m_lsDroppedFiles;
};

#endif //__SENDTOSHLEXT_H_
