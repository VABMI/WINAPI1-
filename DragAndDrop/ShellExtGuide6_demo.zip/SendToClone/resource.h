//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SendToClone.rc
//
#define IDI_MAINICON                    48
#define IDS_PROJNAME                    100
#define IDR_SENDTOSHLEXT                102
#define IDC_FILE_LIST                   201
#define IDD_MAINDLG                     201
#define IDC_TARGET_DIR                  202
#define IDC_BROWSE                      203
#define IDC_COPY                        204
#define IDC_MOVE                        205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
